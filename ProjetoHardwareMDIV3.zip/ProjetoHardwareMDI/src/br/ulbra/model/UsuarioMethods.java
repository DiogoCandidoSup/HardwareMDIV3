/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ulbra.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import java.util.Comparator;

import javax.swing.JOptionPane;

/**
 *
 * @author Diogo
 */
public class UsuarioMethods 
{
    public static List<Usuario> bdUsu;
    
    public UsuarioMethods()
    {
        bdUsu = new ArrayList();
    }
    
    public void adicionar(Usuario usu)
    {
        bdUsu.add(usu);
        JOptionPane.showMessageDialog(null, "Usuario Salvo com Sucesso!");
    }
    
    public void alterar(int i, Usuario usu)
    {
        bdUsu.set(i, usu);
        JOptionPane.showMessageDialog(null ,"Registro modificado com Sucesso!!");
    }
        
    public void excluir(int i)
    {
        if(!bdUsu.isEmpty()) //checks if is NOT empty
        {
            if(JOptionPane.showConfirmDialog(null, "Apagar registro?", "Eliminar registro", JOptionPane.YES_NO_OPTION ) == JOptionPane.YES_OPTION)
            {
                bdUsu.remove(i); //deletes value
                JOptionPane.showMessageDialog(null, "Registro eliminado com sucesso"); //out sucess
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Operação cancelada"); //out canceled
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Base vazia"); //out insucess
        }
    }
    
    public void eliminarBase()
    {
        if(!bdUsu.isEmpty()) //checks if is NOT empty
        {
            if(JOptionPane.showConfirmDialog(null, "Apagar?", "Eliminar base", JOptionPane.YES_NO_OPTION ) == JOptionPane.YES_OPTION)
            {
                bdUsu.clear(); //deletes values
                JOptionPane.showMessageDialog(null, "Base eliminada com sucesso"); //out sucess
            }
            else
            {
                JOptionPane.showMessageDialog(null, "A base nao foi apagada"); //out canceled
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Base vazia"); //out insucess
        }
    }
    
    
    /*
    public ArrayList listarU(int tipo,int p)
    {
        ArrayList<Usuario> res = new ArrayList();
        Usuario u = new Usuario();
        int i;
        for(i=0; i<bdUsu.size();i++)
        {
            u.setId(bdUsu.get(i).getId());
            u.setNome(bdUsu.get(i).getNome());
            u.setEmail(bdUsu.get(i).getEmail());
            u.setSenha(bdUsu.get(i).getSenha());
            u.setSexo(bdUsu.get(i).getSexo());
            res.add(u);
        }
      
        if(tipo == 0)
        {
           res = res;
        }
        else if (tipo == 1)
        {
            res.sort(Comparator.comparing(Usuario::getNome));
        }
        else if(tipo == 2)
        {
            res.sort(Comparator.comparing(Usuario::getNome).reversed());
        }
        else
        {
        //por nome
        //  res = res.get(p).getNome();
        }
        return res;
    }
    */
}

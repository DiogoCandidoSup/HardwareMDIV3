/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ulbra.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Diogo
 */
public class HardwareMethods 
{
    public static List<Hardware> bdHard;
    
    public HardwareMethods()
    {
        bdHard = new ArrayList();
    }
    
    public void adicionar(Hardware hard)
    {
        bdHard.add(hard);
        JOptionPane.showMessageDialog(null, "item Salvo com Sucesso!");
    }
    
    
    
    
    
    /*
    public List<Hardware> hards;

    public HardwareMethods() 
    {
        hards = new ArrayList<Hardware>();
    }
    
    public void adicionar(Hardware hard) //add value to array
    {
        hards.add(hard); //save value to array
        
        JOptionPane.showMessageDialog(null, "O registro " + hard + " foi adicionado com sucesso");
    }
    
    public String listarHards() //list values from --- array MUDAR PARA LISTA TABELA, PEGAR DE OUTRO PROJETO
    {
        String rel = "Items\n\n=================================\n\n";
        
        if(!hards.isEmpty()) //check if is NOT empty
        {
            for(int i = 0; i < hards.size(); i++) //loop
            {
                rel += (i + 1) + " - " + hards.get(i) + "\n";
            }
        }
        else
        {
            rel = "Base vazia"; //out insucess
        }
        return rel; //return values
    } 
    
    public void eliminar() //delete all values
    {
        if(!hards.isEmpty()) //checks if is NOT empty
        {
            if(JOptionPane.showConfirmDialog(null, "Apagar?", "Eliminar base", JOptionPane.YES_NO_OPTION ) == JOptionPane.YES_OPTION)
            {
                hards.clear(); //deletes values
                JOptionPane.showMessageDialog(null, "Base eliminada com sucesso"); //out sucess
            }
            else
            {
                JOptionPane.showMessageDialog(null, "A base nao foi apagada"); //out canceled
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Base vazia"); //out insucess
        }
    }
    
    public boolean returnVazio()
    {
        return hards.isEmpty();
    }
    
    public int pesquisar(String nome) //search values in list
    {
        boolean flag = false; //variables
        int i = 0;
        int ind = -1;
            
        while(i < hards.size() && !(flag)) //check if values exists && flag(found) is true
        {
            if(hards.get(i).equals(nome.toUpperCase())) //compares to name searched
            {
                flag = true; //found search, stops loop
                ind = i;
            }
                
            i++;
        }
            
        return ind;
    }
    
    public void excluir(int i)
    {
        if(!hards.isEmpty()) //checks if is NOT empty
        {
            if(JOptionPane.showConfirmDialog(null, "Apagar registro?", "Eliminar registro", JOptionPane.YES_NO_OPTION ) == JOptionPane.YES_OPTION)
            {
                hards.remove(i); //deletes value
                JOptionPane.showMessageDialog(null, "Registro eliminado com sucesso"); //out sucess
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Operação cancelada"); //out canceled
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "Base vazia"); //out insucess
        }
    }
    
    public void editar(int i, Hardware novoNome) //edit value
    {
        hards.set(i, novoNome);
    }
    
    public String ordenar()
    {
        //Collections.sort(hards); //a-z
        JOptionPane.showMessageDialog(null, "Ordenado de forma crescente"); //out sucess
        
        return null;
    }
    
    public void desordenar()
    {
        Collections.sort(hards, Collections.reverseOrder()); //z-a
        JOptionPane.showMessageDialog(null, "Ordenado de forma decrescente"); //out sucess
    }
    
    public int encontrarMarca(Hardware marca)
    {
        boolean flag = false; //variables
        int i = 0;
        int ind = -1;
            
        while(i < hards.size() && !(flag)) //check if values exists && flag(found) is true
        {
            if(hards.get(i).equals(marca.getMarca())) //compares to name searched
            {
                flag = true; //found search, stops loop
                ind = i;
            }
                
            i++;
        }
            
        return ind;
    }
    
    public int encontrarNome(Hardware nome)
    {
        boolean flag = false; //variables
        int i = 0;
        int ind = -1;
            
        while(i < hards.size() && !(flag)) //check if values exists && flag(found) is true
        {
            if(hards.get(i).equals(nome.getNome())) //compares to name searched
            {
                flag = true; //found search, stops loop
                ind = i;
            }
                
            i++;
        }
            
        return ind;
    }
    */
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ulbra.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author s.lucas
 */
public class Hardware 
{
    private int id;
    private String nome;
    private String marca;
    private String categoria;
    private int dataCom;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getDataCom() {
        return dataCom;
    }

    public void setDataCom(int dataCom) {
        this.dataCom = dataCom;
    }

    @Override
    public String toString() {
        return "Hardware{" + "id=" + id + ", nome=" + nome + ", marca=" + marca + ", categoria=" + categoria + ", dataCom=" + dataCom + '}';
    }
 
//==============================================================================
    
    //public ArrayList <String> hards = new ArrayList();
    
       
    
}
